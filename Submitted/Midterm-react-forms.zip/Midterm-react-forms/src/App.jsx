import Form from "./components/Form/Form";

function App() {
  return (
    <div>
      <h1>Employee Registration Form</h1>
      {<Form />}
    </div>
  );
};

export default App

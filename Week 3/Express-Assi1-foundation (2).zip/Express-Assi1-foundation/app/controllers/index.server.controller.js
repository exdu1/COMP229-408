exports.render = function (req, res) {
    res.render('index', {
        title: 'New Express Application'
    })
};